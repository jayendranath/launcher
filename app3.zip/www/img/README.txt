README

Use this folder for static images, loading gifs, etc.